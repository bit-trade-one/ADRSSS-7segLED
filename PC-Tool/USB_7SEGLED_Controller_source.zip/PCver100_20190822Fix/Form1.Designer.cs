namespace HID_PnP_Demo
{


    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.StatusBox_lbl = new System.Windows.Forms.Label();
            this.StatusBox_lbl2 = new System.Windows.Forms.Label();
            this.Status_C_pb = new System.Windows.Forms.PictureBox();
            this.Status_NC_pb = new System.Windows.Forms.PictureBox();
            this.lbl_FW_Version = new System.Windows.Forms.Label();
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.PushbuttonStateTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.ToggleLEDToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.FormUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.ReadWriteThread = new System.ComponentModel.BackgroundWorker();
            this.setting_btn = new System.Windows.Forms.Button();
            this.reset_btn = new System.Windows.Forms.Button();
            this.txtbx_set_num = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.colum_lbl = new System.Windows.Forms.Label();
            this.Debug_label3 = new System.Windows.Forms.Label();
            this.Debug_label4 = new System.Windows.Forms.Label();
            this.Debug_label2 = new System.Windows.Forms.Label();
            this.Debug_label1 = new System.Windows.Forms.Label();
            this.rdbtn_zf = new System.Windows.Forms.RadioButton();
            this.rdbtn_bl = new System.Windows.Forms.RadioButton();
            this.gbx_zeroPlace = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gbx_read = new System.Windows.Forms.GroupBox();
            this.btn_read_num = new System.Windows.Forms.Button();
            this.txtbx_read_num = new System.Windows.Forms.TextBox();
            this.gbx_write = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.gbx_zeroPlace.SuspendLayout();
            this.gbx_read.SuspendLayout();
            this.gbx_write.SuspendLayout();
            this.SuspendLayout();
            // 
            // StatusBox_lbl
            // 
            this.StatusBox_lbl.AutoSize = true;
            this.StatusBox_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.StatusBox_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl.Location = new System.Drawing.Point(212, 219);
            this.StatusBox_lbl.Name = "StatusBox_lbl";
            this.StatusBox_lbl.Size = new System.Drawing.Size(79, 12);
            this.StatusBox_lbl.TabIndex = 117;
            this.StatusBox_lbl.Text = "�f�o�C�X���ڑ�";
            // 
            // StatusBox_lbl2
            // 
            this.StatusBox_lbl2.AutoSize = true;
            this.StatusBox_lbl2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(214)))), ((int)(((byte)(214)))));
            this.StatusBox_lbl2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.StatusBox_lbl2.Location = new System.Drawing.Point(393, 125);
            this.StatusBox_lbl2.Name = "StatusBox_lbl2";
            this.StatusBox_lbl2.Size = new System.Drawing.Size(216, 12);
            this.StatusBox_lbl2.TabIndex = 118;
            this.StatusBox_lbl2.Text = "7SEG LED Configuration Tool�N�����܂���";
            // 
            // Status_C_pb
            // 
            this.Status_C_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_C_pb.Image = global::USB_7SEGLED_Controller.Properties.Resources.ON;
            this.Status_C_pb.Location = new System.Drawing.Point(297, 221);
            this.Status_C_pb.Name = "Status_C_pb";
            this.Status_C_pb.Size = new System.Drawing.Size(27, 10);
            this.Status_C_pb.TabIndex = 94;
            this.Status_C_pb.TabStop = false;
            this.Status_C_pb.Visible = false;
            // 
            // Status_NC_pb
            // 
            this.Status_NC_pb.BackColor = System.Drawing.Color.Transparent;
            this.Status_NC_pb.Image = global::USB_7SEGLED_Controller.Properties.Resources.OFF;
            this.Status_NC_pb.Location = new System.Drawing.Point(297, 221);
            this.Status_NC_pb.Name = "Status_NC_pb";
            this.Status_NC_pb.Size = new System.Drawing.Size(27, 10);
            this.Status_NC_pb.TabIndex = 95;
            this.Status_NC_pb.TabStop = false;
            this.Status_NC_pb.Visible = false;
            // 
            // lbl_FW_Version
            // 
            this.lbl_FW_Version.AutoSize = true;
            this.lbl_FW_Version.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(106)))), ((int)(((byte)(106)))), ((int)(((byte)(106)))));
            this.lbl_FW_Version.Location = new System.Drawing.Point(14, 219);
            this.lbl_FW_Version.Name = "lbl_FW_Version";
            this.lbl_FW_Version.Size = new System.Drawing.Size(23, 12);
            this.lbl_FW_Version.TabIndex = 150;
            this.lbl_FW_Version.Text = "***";
            // 
            // toolTip2
            // 
            this.toolTip2.AutomaticDelay = 20;
            this.toolTip2.AutoPopDelay = 20000;
            this.toolTip2.InitialDelay = 15;
            this.toolTip2.ReshowDelay = 15;
            // 
            // toolTip1
            // 
            this.toolTip1.AutomaticDelay = 2000;
            this.toolTip1.AutoPopDelay = 20000;
            this.toolTip1.InitialDelay = 15;
            this.toolTip1.ReshowDelay = 15;
            // 
            // PushbuttonStateTooltip
            // 
            this.PushbuttonStateTooltip.AutomaticDelay = 20;
            this.PushbuttonStateTooltip.AutoPopDelay = 20000;
            this.PushbuttonStateTooltip.InitialDelay = 15;
            this.PushbuttonStateTooltip.ReshowDelay = 15;
            // 
            // ToggleLEDToolTip
            // 
            this.ToggleLEDToolTip.AutomaticDelay = 2000;
            this.ToggleLEDToolTip.AutoPopDelay = 20000;
            this.ToggleLEDToolTip.InitialDelay = 15;
            this.ToggleLEDToolTip.ReshowDelay = 15;
            // 
            // FormUpdateTimer
            // 
            this.FormUpdateTimer.Enabled = true;
            this.FormUpdateTimer.Interval = 6;
            this.FormUpdateTimer.Tick += new System.EventHandler(this.FormUpdateTimer_Tick);
            // 
            // ReadWriteThread
            // 
            this.ReadWriteThread.WorkerReportsProgress = true;
            this.ReadWriteThread.DoWork += new System.ComponentModel.DoWorkEventHandler(this.ReadWriteThread_DoWork);
            // 
            // setting_btn
            // 
            this.setting_btn.Location = new System.Drawing.Point(195, 111);
            this.setting_btn.Name = "setting_btn";
            this.setting_btn.Size = new System.Drawing.Size(75, 23);
            this.setting_btn.TabIndex = 221;
            this.setting_btn.Text = "�ݒ�";
            this.setting_btn.UseVisualStyleBackColor = true;
            this.setting_btn.Click += new System.EventHandler(this.setting_btn_Click);
            // 
            // reset_btn
            // 
            this.reset_btn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.reset_btn.Location = new System.Drawing.Point(36, 111);
            this.reset_btn.Name = "reset_btn";
            this.reset_btn.Size = new System.Drawing.Size(75, 23);
            this.reset_btn.TabIndex = 220;
            this.reset_btn.Text = "���Z�b�g";
            this.reset_btn.UseVisualStyleBackColor = true;
            this.reset_btn.Click += new System.EventHandler(this.reset_btn_Click);
            // 
            // txtbx_set_num
            // 
            this.txtbx_set_num.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtbx_set_num.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtbx_set_num.Location = new System.Drawing.Point(11, 35);
            this.txtbx_set_num.MaxLength = 32;
            this.txtbx_set_num.Name = "txtbx_set_num";
            this.txtbx_set_num.Size = new System.Drawing.Size(295, 23);
            this.txtbx_set_num.TabIndex = 202;
            this.txtbx_set_num.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtbx_set_num.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Black;
            this.groupBox1.Controls.Add(this.colum_lbl);
            this.groupBox1.Controls.Add(this.Debug_label3);
            this.groupBox1.Controls.Add(this.Debug_label4);
            this.groupBox1.Controls.Add(this.Debug_label2);
            this.groupBox1.Controls.Add(this.Debug_label1);
            this.groupBox1.Location = new System.Drawing.Point(6, 262);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(878, 129);
            this.groupBox1.TabIndex = 901;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DEBUG";
            // 
            // colum_lbl
            // 
            this.colum_lbl.AutoSize = true;
            this.colum_lbl.BackColor = System.Drawing.Color.Black;
            this.colum_lbl.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.colum_lbl.ForeColor = System.Drawing.Color.White;
            this.colum_lbl.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.colum_lbl.Location = new System.Drawing.Point(15, 24);
            this.colum_lbl.Name = "colum_lbl";
            this.colum_lbl.Size = new System.Drawing.Size(56, 16);
            this.colum_lbl.TabIndex = 901;
            this.colum_lbl.Text = "label1";
            // 
            // Debug_label3
            // 
            this.Debug_label3.AutoSize = true;
            this.Debug_label3.BackColor = System.Drawing.Color.Black;
            this.Debug_label3.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.Debug_label3.ForeColor = System.Drawing.Color.White;
            this.Debug_label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Debug_label3.Location = new System.Drawing.Point(15, 84);
            this.Debug_label3.Name = "Debug_label3";
            this.Debug_label3.Size = new System.Drawing.Size(56, 16);
            this.Debug_label3.TabIndex = 904;
            this.Debug_label3.Text = "debug1";
            // 
            // Debug_label4
            // 
            this.Debug_label4.AutoSize = true;
            this.Debug_label4.BackColor = System.Drawing.Color.Black;
            this.Debug_label4.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.Debug_label4.ForeColor = System.Drawing.Color.White;
            this.Debug_label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Debug_label4.Location = new System.Drawing.Point(15, 104);
            this.Debug_label4.Name = "Debug_label4";
            this.Debug_label4.Size = new System.Drawing.Size(56, 16);
            this.Debug_label4.TabIndex = 905;
            this.Debug_label4.Text = "debug1";
            // 
            // Debug_label2
            // 
            this.Debug_label2.AutoSize = true;
            this.Debug_label2.BackColor = System.Drawing.Color.Black;
            this.Debug_label2.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.Debug_label2.ForeColor = System.Drawing.Color.White;
            this.Debug_label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Debug_label2.Location = new System.Drawing.Point(15, 64);
            this.Debug_label2.Name = "Debug_label2";
            this.Debug_label2.Size = new System.Drawing.Size(56, 16);
            this.Debug_label2.TabIndex = 903;
            this.Debug_label2.Text = "debug1";
            // 
            // Debug_label1
            // 
            this.Debug_label1.AutoSize = true;
            this.Debug_label1.BackColor = System.Drawing.Color.Black;
            this.Debug_label1.Font = new System.Drawing.Font("�l�r �S�V�b�N", 12F);
            this.Debug_label1.ForeColor = System.Drawing.Color.White;
            this.Debug_label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.Debug_label1.Location = new System.Drawing.Point(15, 44);
            this.Debug_label1.Name = "Debug_label1";
            this.Debug_label1.Size = new System.Drawing.Size(56, 16);
            this.Debug_label1.TabIndex = 902;
            this.Debug_label1.Text = "debug1";
            // 
            // rdbtn_zf
            // 
            this.rdbtn_zf.AutoSize = true;
            this.rdbtn_zf.Location = new System.Drawing.Point(150, 18);
            this.rdbtn_zf.Name = "rdbtn_zf";
            this.rdbtn_zf.Size = new System.Drawing.Size(66, 16);
            this.rdbtn_zf.TabIndex = 212;
            this.rdbtn_zf.Text = "Zero Fill";
            this.rdbtn_zf.UseVisualStyleBackColor = true;
            this.rdbtn_zf.CheckedChanged += new System.EventHandler(this.rdbtn_fillcfg_CheckedChanged);
            // 
            // rdbtn_bl
            // 
            this.rdbtn_bl.AutoSize = true;
            this.rdbtn_bl.Checked = true;
            this.rdbtn_bl.Location = new System.Drawing.Point(15, 18);
            this.rdbtn_bl.Name = "rdbtn_bl";
            this.rdbtn_bl.Size = new System.Drawing.Size(52, 16);
            this.rdbtn_bl.TabIndex = 211;
            this.rdbtn_bl.TabStop = true;
            this.rdbtn_bl.Text = "Blank";
            this.rdbtn_bl.UseVisualStyleBackColor = true;
            this.rdbtn_bl.CheckedChanged += new System.EventHandler(this.rdbtn_fillcfg_CheckedChanged);
            // 
            // gbx_zeroPlace
            // 
            this.gbx_zeroPlace.Controls.Add(this.rdbtn_zf);
            this.gbx_zeroPlace.Controls.Add(this.rdbtn_bl);
            this.gbx_zeroPlace.Location = new System.Drawing.Point(11, 65);
            this.gbx_zeroPlace.Name = "gbx_zeroPlace";
            this.gbx_zeroPlace.Size = new System.Drawing.Size(295, 40);
            this.gbx_zeroPlace.TabIndex = 210;
            this.gbx_zeroPlace.TabStop = false;
            this.gbx_zeroPlace.Text = "�[���v���[�X�z���_�w��";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 201;
            this.label1.Text = "���l";
            // 
            // gbx_read
            // 
            this.gbx_read.Controls.Add(this.btn_read_num);
            this.gbx_read.Controls.Add(this.txtbx_read_num);
            this.gbx_read.Location = new System.Drawing.Point(10, 12);
            this.gbx_read.Name = "gbx_read";
            this.gbx_read.Size = new System.Drawing.Size(318, 47);
            this.gbx_read.TabIndex = 100;
            this.gbx_read.TabStop = false;
            this.gbx_read.Text = "�ǂݍ���";
            // 
            // btn_read_num
            // 
            this.btn_read_num.Location = new System.Drawing.Point(243, 17);
            this.btn_read_num.Name = "btn_read_num";
            this.btn_read_num.Size = new System.Drawing.Size(70, 25);
            this.btn_read_num.TabIndex = 102;
            this.btn_read_num.Text = "�ǂݍ���";
            this.btn_read_num.UseVisualStyleBackColor = true;
            this.btn_read_num.Click += new System.EventHandler(this.btn_read_num_Click);
            // 
            // txtbx_read_num
            // 
            this.txtbx_read_num.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.txtbx_read_num.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.txtbx_read_num.Location = new System.Drawing.Point(9, 18);
            this.txtbx_read_num.MaxLength = 32;
            this.txtbx_read_num.Name = "txtbx_read_num";
            this.txtbx_read_num.ReadOnly = true;
            this.txtbx_read_num.Size = new System.Drawing.Size(235, 23);
            this.txtbx_read_num.TabIndex = 101;
            this.txtbx_read_num.TabStop = false;
            this.txtbx_read_num.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gbx_write
            // 
            this.gbx_write.Controls.Add(this.label1);
            this.gbx_write.Controls.Add(this.setting_btn);
            this.gbx_write.Controls.Add(this.reset_btn);
            this.gbx_write.Controls.Add(this.gbx_zeroPlace);
            this.gbx_write.Controls.Add(this.txtbx_set_num);
            this.gbx_write.Location = new System.Drawing.Point(10, 65);
            this.gbx_write.Name = "gbx_write";
            this.gbx_write.Size = new System.Drawing.Size(318, 145);
            this.gbx_write.TabIndex = 200;
            this.gbx_write.TabStop = false;
            this.gbx_write.Text = "��������";
            // 
            // Form1
            // 
            this.AcceptButton = this.setting_btn;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.CancelButton = this.reset_btn;
            this.ClientSize = new System.Drawing.Size(896, 392);
            this.Controls.Add(this.gbx_write);
            this.Controls.Add(this.gbx_read);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbl_FW_Version);
            this.Controls.Add(this.Status_C_pb);
            this.Controls.Add(this.StatusBox_lbl2);
            this.Controls.Add(this.StatusBox_lbl);
            this.Controls.Add(this.Status_NC_pb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "7SEG LED Configuration Tool ver 1.0.0";
            ((System.ComponentModel.ISupportInitialize)(this.Status_C_pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Status_NC_pb)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbx_zeroPlace.ResumeLayout(false);
            this.gbx_zeroPlace.PerformLayout();
            this.gbx_read.ResumeLayout(false);
            this.gbx_read.PerformLayout();
            this.gbx_write.ResumeLayout(false);
            this.gbx_write.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox Status_C_pb;
        private System.Windows.Forms.PictureBox Status_NC_pb;
        private System.Windows.Forms.Label StatusBox_lbl;
        private System.Windows.Forms.Label StatusBox_lbl2;
        private System.Windows.Forms.Label lbl_FW_Version;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip PushbuttonStateTooltip;
        private System.Windows.Forms.ToolTip ToggleLEDToolTip;
        private System.Windows.Forms.Timer FormUpdateTimer;
        private System.ComponentModel.BackgroundWorker ReadWriteThread;
        private System.Windows.Forms.Button setting_btn;
        private System.Windows.Forms.Button reset_btn;
        private System.Windows.Forms.TextBox txtbx_set_num;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label colum_lbl;
        private System.Windows.Forms.Label Debug_label3;
        private System.Windows.Forms.Label Debug_label4;
        private System.Windows.Forms.Label Debug_label2;
        private System.Windows.Forms.Label Debug_label1;
        private System.Windows.Forms.RadioButton rdbtn_zf;
        private System.Windows.Forms.RadioButton rdbtn_bl;
        private System.Windows.Forms.GroupBox gbx_zeroPlace;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox gbx_read;
        private System.Windows.Forms.Button btn_read_num;
        private System.Windows.Forms.TextBox txtbx_read_num;
        private System.Windows.Forms.GroupBox gbx_write;
    }
}

