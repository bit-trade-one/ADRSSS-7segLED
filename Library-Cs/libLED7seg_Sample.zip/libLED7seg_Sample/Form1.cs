﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using Microsoft.Win32.SafeHandles;
using libLED7seg;

namespace _7segLibrarySample {
    public partial class Form1 : Form {
        SafeFileHandle handleUSB = null;
        long counter = 0;

        public Form1() {
            InitializeComponent();
            //SafeFileHandle handleUSB = null;
            //handleUSB = LED7seg.open7SEGLED(this.Handle);
            //if (handleUSB != -1) {
            //    ReadWriteThread.RunWorkerAsync();
            //}
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = LED7seg.open7SEGLED(this.Handle);
                if (handle_usb_device != null)
                {
                    string str_temp = textBox1.Text;
                    int int_temp = str_temp[0];
                    byte byte_temp = (byte)(str_temp[0] & 0xFF);
                    // 表示データ設定
                    i_ret = LED7seg.Write7SEGData(handle_usb_device, textBox1.Text);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = LED7seg.close7SEGLED(handle_usb_device);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = LED7seg.open7SEGLED(this.Handle);
                if (handle_usb_device != null)
                {
                    bool set_config = false;
                    if(radioButton1.Checked == true)
                    {
                        set_config = false;
                    }
                    else if(radioButton2.Checked == true)
                    {
                        set_config = true;
                    }
                    // ゼロプレース設定
                    i_ret = LED7seg.SetZeroPlaceHolder(handle_usb_device, set_config);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = LED7seg.close7SEGLED(handle_usb_device);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = LED7seg.open7SEGLED(this.Handle);
                if (handle_usb_device != null)
                {
                    string read_str = "";
                    // 表示データ取得
                    i_ret = LED7seg.Read7SEGData(handle_usb_device, ref read_str);
                    textBox3.Text = read_str;
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = LED7seg.close7SEGLED(handle_usb_device);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SafeFileHandle handle_usb_device = null;    // USB DEVICEハンドル
            int i_ret = 0;
            try
            {
                // USB DEVICEオープン
                handle_usb_device = LED7seg.open7SEGLED(this.Handle);
                if (handle_usb_device != null)
                {
                    // リセット設定
                    i_ret = LED7seg.Reset7SEG(handle_usb_device);
                }
            }
            catch
            {
            }
            finally
            {
                if (handle_usb_device != null)
                {
                    // USB DEVICEクローズ
                    i_ret = LED7seg.close7SEGLED(handle_usb_device);
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if ((e.KeyChar < '0' || '9' < e.KeyChar) && (e.KeyChar < 'a' || 'f' < e.KeyChar) && (e.KeyChar < 'A' || 'F' < e.KeyChar) && e.KeyChar != '\b' && e.KeyChar != '.' && e.KeyChar != ' ' && e.KeyChar != '-')
                {
                    e.Handled = true;
                }
            }
            catch
            {
            }
        }
    }
}
