// USB7SEGControllerLibSample.cpp : �R���\�[�� �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//

#include "stdafx.h"
#include "USB7SEGControllerLib.h"

#define DEVICE_ID_NUM			1
#define MAX_NUMBER_DIGITS		32
#define ZERO_PLACE_DISABLED		0x10
#define ZERO_PLACE_ENABLED		0x11

int _tmain(int argc, _TCHAR* argv[])
{
	int type = 0;
	int d_id = 0;
	int set_val = 0;
	int i_ret;
	int para1, para2;
	BYTE* para_arry;
	BYTE set_data_arry[MAX_NUMBER_DIGITS];
	BYTE get_data_arry[MAX_NUMBER_DIGITS];
	char temp_buff[0x100];
	int fi;
	BYTE check_flag = 0;
	clock_t start_time, end_time;
	int count = 0;

	HMODULE hHandle = GetModuleHandle(0);
	//openUSB(hHandle);
	HANDLE usbHandle[DEVICE_ID_NUM] = {NULL};

	while(1)
	{
		printf_s("\n�������e��I�����ĉ������B\n");
		printf("1:USB�ڑ�\n");
		printf("2:USB�ؒf\n");
		printf("3:�\���o�͐ݒ�\n");
		printf("4:�[���v���[�Y�ݒ�\n");
		printf("5:�\����Ԏ擾\n");
		printf("6:���Z�b�g\n");
		printf("99:�I��\n");
		rewind(stdin);
		type = 0;
		printf("�����ԍ� ? = ");
		scanf_s("%d", &type);

		if(type == 99)
		{
			break;
		}


		switch(type)
		{
			case 1:
				start_time = clock();
				usbHandle[d_id] = open7SEGLED(hHandle);
				end_time = clock();
				printf("%d\n", usbHandle[d_id]);
				printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				break;
			case 2:
				start_time = clock();
				i_ret = close7SEGLED(usbHandle[d_id]);
				end_time = clock();
				usbHandle[d_id] = NULL;
				printf("%d\n", i_ret);
				printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				break;
			case 3:
				count = 0;
				for(fi = 0; fi < MAX_NUMBER_DIGITS; fi++)
				{
					set_data_arry[fi] = 0x00;
				}
				printf("�\�����鐔�l ? ([0�`9][a�`f][-][.]) = ");
				scanf_s("%s", temp_buff, 0x100);
				//gets(temp_buff);
				for(fi = 0; fi < sizeof(temp_buff); fi++)
				{
					if(temp_buff[fi] == 0x00)
					{
						break;
					}
					if('0' <= temp_buff[fi] && temp_buff[fi] <= '9')
					{
						set_data_arry[count++] = temp_buff[fi] - '0';
					}
					else if('a' <= temp_buff[fi] && temp_buff[fi] <= 'f')
					{
						set_data_arry[count++] = temp_buff[fi] - 'a' + 0x0a;
					}
					else if('A' <= temp_buff[fi] && temp_buff[fi] <= 'F')
					{
						set_data_arry[count++] = temp_buff[fi] - 'A' + 0x0a;
					}
					else if(temp_buff[fi] == '.')
					{
						if(fi == 0)
						{
							set_data_arry[count++] = 0x20;
						}
						else if(temp_buff[fi-1] != '.' && temp_buff[fi-1] != '-')
						{
							set_data_arry[count-1] |= 0x10;
						}
						else
						{
							set_data_arry[count++] = 0x20;
						}
					}
					else if(temp_buff[fi] == '-')
					{
						set_data_arry[count++] = 0x22;
					}

					if(count >= MAX_NUMBER_DIGITS)
					{
						break;
					}
				}
				start_time = clock();
				i_ret = write7SEGData(usbHandle[d_id], set_data_arry, count);
				end_time = clock();
				printf("%d\n", i_ret);
				printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				break;
			case 4:
				check_flag	= 0;
				printf("Zero place set? (0:disabled, 1:enabled) = ");
				scanf_s("%d", &para1);
				if(para1 == 1)
				{
					para1 = ZERO_PLACE_ENABLED;
				}
				else
				{
					para1 = ZERO_PLACE_DISABLED;
				}
				if(check_flag == 0)
				{
					start_time = clock();
					i_ret = setZeroPlaceHolder(usbHandle[d_id], (BYTE)(para1 & 0xFF));
					end_time = clock();
					printf("%d\n", i_ret);
					printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				}
				break;
			case 5:
				check_flag	= 0;
				if(check_flag == 0)
				{
					start_time = clock();
					i_ret = read7SEGData(usbHandle[d_id], get_data_arry, MAX_NUMBER_DIGITS);
					end_time = clock();
					for(fi = 0; fi < MAX_NUMBER_DIGITS; fi++)
					{
						if(get_data_arry[fi] == 0x00)
						{
							break;
						}
						else if(0x00 <= get_data_arry[fi] && get_data_arry[fi] <= 0x0F)
						{
							printf("%X", get_data_arry[fi]);
						}
						else if(0x10 <= get_data_arry[fi] && get_data_arry[fi] <= 0x1F)
						{
							printf("%X.", get_data_arry[fi] - 0x10);
						}
						else if(0x20 == get_data_arry[fi])
						{
							printf(".");
						}
						else if(0x21 == get_data_arry[fi])
						{
							printf(" ");
						}
						else if(0x22 == get_data_arry[fi])
						{
							printf("-");
						}
					}
					printf("\n");
					printf("%d\n", i_ret);
					printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				}
				break;
			case 6:
				check_flag	= 0;
				if(check_flag == 0)
				{
					start_time = clock();
					i_ret = reset7SEG(usbHandle[d_id]);
					end_time = clock();
					printf("%d\n", i_ret);
					printf("%.3f�b������܂����B\n", (double)(end_time-start_time) / CLOCKS_PER_SEC);
				}
				break;
			default:
				printf("\n�����ԍ�������������܂���I�I�I\n\n");
				break;

		}

	}

	// Open���Ă���USB���N���[�Y����
	for(int fi = 0; fi < DEVICE_ID_NUM; fi++)
	{
		if(usbHandle[d_id] != NULL)
		{
			i_ret = close7SEGLED(usbHandle[d_id]);
		}
	}

	return 0;
}

