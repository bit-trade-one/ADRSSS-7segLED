//USB7SEGControllerLib.h
#include "stdafx.h"

#ifdef __cplusplus
#define EXPORT extern "C" __declspec (dllexport)
#else
#define EXPORT __declspec (dllexport)
#endif

EXPORT HANDLE __stdcall open7SEGLED(HANDLE hRecipient);
EXPORT int __stdcall close7SEGLED(HANDLE HandleToUSBDevice);
EXPORT int __stdcall write7SEGData(HANDLE HandleToUSBDevice, BYTE* set_data, int set_data_len);
EXPORT int __stdcall setZeroPlaceHolder(HANDLE HandleToUSBDevice, BYTE set_flag);
EXPORT int __stdcall read7SEGData(HANDLE HandleToUSBDevice, BYTE* read_data, int read_buff_len);
EXPORT int __stdcall reset7SEG(HANDLE HandleToUSBDevice);


